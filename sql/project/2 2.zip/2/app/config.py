class Config:
    MYSQL_HOST = "localhost"
    MYSQL_DATABASE = "ecommerce"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = ""
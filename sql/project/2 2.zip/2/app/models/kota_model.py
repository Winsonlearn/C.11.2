import mysql.connector
from flask import current_app


class KotaModel:
    def __init__(self):
        self.config = current_app.config
    
    def connect(self):
        return mysql.connector.connect(
            host = self.config["MYSQL_HOST"],
            database = self.config["MYSQL_DATABASE"],
            user = self.config["MYSQL_USER"],
            password = self.config["MYSQL_PASSWORD"],
        )
    
    def get_all_kota(self):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select * from kota")
        data = cursor.fetchall()
        cursor.close()
        db.close()
        return data
        
    def get_kota_by_id(self, id):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select * from kota where id = %s", (id,))
        data = cursor.fetchone()
        cursor.close()
        db.close()
        return data
        
    def insert_kota(self, nama):
        db = self.connect()
        cursor = db.cursor()
        query = "insert into kota (id, nama) values (%s, %s)"
        data = (None, nama)  
        cursor.execute(query, data)
        db.commit()
        cursor.close()
        db.close()
        return 0
        
    def update_kota(self, id, nama):
        db = self.connect()
        cursor = db.cursor()
        query = "update kota set nama = %s where id = %s"
        cursor.execute(query, (nama, id))
        db.commit()
        cursor.close()
        db.close()
        return 0
        
    def delete_kota(self, id):
        db = self.connect()
        cursor = db.cursor()
        query = "delete from kota where id = %s"
        cursor.execute(query, (id,))
        db.commit()
        cursor.close()
        db.close()
        return 0
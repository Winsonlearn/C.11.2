import mysql.connector
from flask import *


class KotaModel:
    def __init__(self):
        self.config = current_app.config
        
        def connect(self):
            return mysql.connector.connect(
                host = self.config("MYSQL_HOST"),
                database = self.config("MYSQL_DATABASE"),
                user = self.config("MYSQL_USER"),
                password = self.config("MYSQL_PASSWORD"),
            )
        
        def get_all_kota(self):
            db = self.connect()
            cursor = db.cursor()
            cursor.execute("select * from kota")
            data = cursor.fetchall()
            cursor.close()
            db.close()
            return data
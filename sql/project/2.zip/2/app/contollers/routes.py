from flask import *
from app.models.kota_model import KotaModel

routes_blueprint = Blueprint('routes', __name__)
@routes_blueprint.routes('/')
@routes_blueprint.routes('/home')
def home():
    return render_templates('/home')